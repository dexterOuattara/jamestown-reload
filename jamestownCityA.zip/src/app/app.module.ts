import { BrowserModule } from '@angular/platform-browser';
import { ErrorHandler, NgModule } from '@angular/core';
import { IonicApp, IonicErrorHandler, IonicModule } from 'ionic-angular';
import { HttpModule } from '@angular/http';
import { HttpClientModule } from '@angular/common/http';
import { BarcodeScanner } from '@ionic-native/barcode-scanner';
import { Toast } from '@ionic-native/toast';

import { MyApp } from './app.component';
import { HomePage } from '../pages/home/home';
import { NewsPage } from '../pages/news/news';
import { AboutPage } from '../pages/about/about';
import { DetailPage } from '../pages/detail/detail';
import { QrcodePage } from '../pages/qrcode/qrcode';
import { LocalisationPage } from '../pages/localisation/localisation';
import { SearchPipe } from '../pipes/search/search';
import { SortPipe } from '../pipes/sort/sort';

import { RestnewProvider } from '../providers/restnew/restnew';
import { RestProvider } from '../providers/rest/rest';


import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import { DataServiceProvider } from '../providers/data-service/data-service';

@NgModule({
  declarations: [
    MyApp,
    HomePage,
    NewsPage,
    AboutPage,
    QrcodePage,
    LocalisationPage,
    SearchPipe,
    SortPipe,
    DetailPage

  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    IonicModule.forRoot(MyApp),
    HttpModule
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    HomePage,
    NewsPage,
    AboutPage,
    QrcodePage,
    LocalisationPage,
    DetailPage
  ],
  providers: [
    StatusBar,
    SplashScreen,
    {provide: ErrorHandler, useClass: IonicErrorHandler},
    RestnewProvider,
    RestProvider,
    BarcodeScanner,
    Toast,
    DataServiceProvider
  ]
})
export class AppModule {}
